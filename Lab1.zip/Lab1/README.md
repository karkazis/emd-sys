## Lab 1
Based on Microchip Explorer 16/32 development board   
- Digital I/Os (Leds/Buttons)
- Timers
- Interrupts
