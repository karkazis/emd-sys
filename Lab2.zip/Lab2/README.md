## Lab 2
Explorer 16/32 development board   
- Ananlog Inputs 
- Analog sensors
- LCD Display